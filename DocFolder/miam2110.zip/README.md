# miam2110
Automation to transfer data from Finanzen.de to Assfinet and KlickTipp

To start the script, please run the __init__.py with python 3


run this command in terminal

python3 __init__.py
